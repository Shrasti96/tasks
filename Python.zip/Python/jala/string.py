# 1. Different ways creating a string

# There are several ways to create a string in Python. Here are some common methods:

# 1. Using Single or Double Quotes:

# str1 = 'Hello, World!'
# str2 = "Python Programming"


# # 2. Using Triple Quotes for Multi-line Strings:

# str3 = '''This is a 
# multi-line string'''
# str4 = """Another multi-
# line string"""


# # 3. Using the str() Function:

# num = 10
# str5 = str(num)

# # 4. Using String Concatenation:

# str6 = "Hello" + " " + "World"


# # 5. Using String Formatting:

# name = "Alice"
# age = 30
# str7 = "My name is {} and I am {} years old.".format(name, age)
# str8 = f"My name is {name} and I am {age} years old."


# # 6. Using Join() Method:

# words = ["Hello", "Python", "World"]
# str9 = " ".join(words)

# # 7. Using the String Constructor:

# str10 = str("Hello, Constructor!")



# 2. Concatenating two strings using + operator

str1 = "Hello, "
str2 = "World!"

result = str1 + str2

# Display the concatenated string
print("Concatenated string:", result)

# 3. Finding the length of the string

print("length of the string:",len(str1))
print()

# 4. Extract a string using Substring
# Original string
original_string = "Hello, World!"

# Extracting a substring "World" from the original string
substring = original_string[7:12]

# Display the extracted substring
print("Extracted substring:", substring)

# 5. Searching in strings using index()
str3 = 'shrasti'
str1 = 'sti'
str2 = 'a'
print("Position of sti:",str3.index(str1))
print("Position of a:",str3.index(str2))
print()

# 6. Matching a String Against a Regular Expression With matches()

import re

input_str = "Hello, World!"
pattern = r"Hello.*"

if re.match(pattern, input_str):
    print("The input matches the pattern.")
else:
    print("The input does not match the pattern.")
    
# 7. Comparing strings

str8 = 'Itachi uchiha'
str1 = 'Madara uchiha'
str2 = str8
print(str8 == str1)
print(str8 == str2)
print(str1 == str2)
print(str8 != str1)
print()

# 8. startsWith(), endsWith() and compareTo()

string = 'Shrasti Sharma'
print(string.startswith("Shrasti"))
print(string.endswith("Sharma"))
print()

# 9. Trimming strings with strip()

str7 = 'Hello Friends hye'
print(str7.strip("hye"))
print()

# 10. Replacing characters in strings with replace()

string = 'Hi World'
print(string.replace("Hi","Hello"))
print()

# 11. Splitting strings with split()

str9 = 'shri-somu-Anu'
print(str9.split("-"))
print()

# 12. Converting integer objects to Strings

num = 100
num1 = str(num)
print(num1)
print(type(num1))



# 13. Converting to uppercase and lowercas

string = 'varun'
string1 = 'MERCURY'
print(string.upper())
print(string1.lower())