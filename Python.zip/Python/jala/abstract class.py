from abc import ABC, abstractmethod

# Abstract class
class Animal(ABC):
    @abstractmethod
    def make_sound(self):
        """Abstract method, must be implemented by subclasses"""
        pass
    
    def sleep(self):
        """Non-abstract method with implementation"""
        print("This animal is sleeping")



# Subclass of Animal
class Dog(Animal):
    def make_sound(self):
        print("Woof woof")

    def fetch(self):
        print("Dog is fetching the ball")

# Instantiate Dog (subclass of Animal)
dog_instance = Dog()
dog_instance.sleep()  # Outputs: This animal is sleeping
dog_instance.fetch()  # Outputs: Dog is fetching the ball




# Inside Dog class definition
class Dog(Animal):
    def make_sound(self):
        print("Woof woof")

    def call_abstract_method(self):
        self.make_sound()  # Calls the overridden make_sound method

# Instantiate Dog (subclass of Animal) within the class itself
dog_instance = Dog()
dog_instance.call_abstract_method() 






# Inside Dog class definition
class Dog(Animal):
    def make_sound(self):
        print("Woof woof")

    def call_non_abstract_method(self):
        self.sleep()  # Calls the inherited non-abstract sleep method

# Instantiate Dog (subclass of Animal) within the class itself
dog_instance = Dog()
dog_instance.call_non_abstract_method()  
