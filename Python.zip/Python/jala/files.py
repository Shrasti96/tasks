# 1. Write a program to read text file 
'''file1 = open("file.txt","r")
data = file1.read()
print(data)
print()'''

# 2. Write a program to write text to .txt file using  InputStream
'''
f2 = open("Wrt.txt","w")
str1 = 'Python'
f2.write(str1)
print()'''

# 3. Write a program to read a file stream
'''
f3 = open("file.txt","r+")
print(f3.readline(11))
print()'''

# 4. Write a program to read a file stream supports random access

'''file_name = "file.txt"
with open(file_name, 'r') as file:
    lines = file.readlines()  
    line2 = lines[1]  
    line3 = lines[2]  
    print(line2, line3)
'''

# 5. Write a program to read a file a just to a particular index using seek()
'''
file_name = "file.txt"
index = 20

with open(file_name, 'r') as file:
    file.seek(index)  
    content = file.read() 
    
print(content)'''

# 6. Write a program to check whether a file is having read access and write access permissions 

import os

def check_permissions(file_path):
    read_access = os.access(file_path, os.R_OK)
    write_access = os.access(file_path, os.W_OK)
    return read_access, write_access

file_path = 'file.txt'  # Replace with your file path
read, write = check_permissions(file_path)
print(f"Read access: {read}, Write access: {write}")




