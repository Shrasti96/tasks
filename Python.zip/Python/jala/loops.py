# 1. Write a program to print “Bright IT Career” ten times using for loop

'''for i in range(10):
    print("Bright IT Career")'''


# 2. Write a java program to print 1 to 20 numbers using the while loop

'''i = 1
#using loop to print 1 to 20 numbers
while(i<=20):
    print(i)
    i+= 1 '''

# 3. Program to equal operator and not equal operator

'''num1 = 10
num2 = 20

if num1 == num2:
    print("The two numbers are equal.")
else:
    print("The two numbers are not equal.")'''

# 4. Write a program to print the odd and even numbers
'''
start = 1
end = 10

print("Even numbers:")
# Print even numbers
for i in range(start, end + 1):
    if i % 2 == 0:
        print(i)

print("\nOdd numbers:")
# Print odd numbers
for i in range(start, end + 1):
    if i % 2 != 0:
        print(i)  '''


# 5. Write a program to print largest number among three numbers
'''
def find_largest(a, b, c):
    if a >= b and a >= c:
        return a
    elif b >= a and b >= c:
        return b
    else:
        return c

# Example usage
num1 = 10
num2 = 25
num3 = 15

# Calling the function and printing the result
largest = find_largest(num1, num2, num3)
print(f"The largest number among {num1}, {num2}, and {num3} is {largest}")'''


# 6. Write a program to print even number between 10 and 20 using while
'''
num = int(input("Enter any number = "))

while num <= 20:
    if num % 2 == 0:  # Checking if the number is even
        print(num)
    num += 1  # Incrementing the number by 1
    '''

# 7. Write a program to print 1 to 10 using the do-while loop statement.

'''num = 1

while True:
    print(num)
    num += 1

    if num > 10:
        break
print()'''


# 8. Write a program to find Armstrong number or not
'''num = int(input("Enter any number = "))
sum = 0
a = num
while a != 0:
    n = a % 10
    a = a // 10
    sum = sum + n*n*n
print(sum)
if sum == num:
    print("number is armstrong")
else:
    print("not armstrong")'''


# 9. Write a program to find the prime or not.
'''
number = int(input("Enter any number to check prime number or not: "))

                    # prime number is always greater than 1
if number > 1:
    for i in range(2, number):
        if (number % i) == 0:
            print(number, "is not a prime number")
            break
    else:
        print(number, "is a prime number")

# if the entered number is less than or equal to 1
# then it is not prime number
else:
    print(number, "is not a prime number")
'''

# 10. Write a program to palindrome or not.
'''''
string = input("Enter a string: ")

# Reversing the input string
reverse_string = string[::-1]

# Checking if the input string is a palindrome
if string == reverse_string:
    print(f"The string '{string}' is a palindrome.")
else:
    print(f"The string '{string}' is not a palindrome.")

'''

# 11. Program to check whether a number is EVEN or ODD using switch

'''num = int(input("Enter a number: "))

# Checking if the number is even or odd
if num % 2 == 0:
    print(f"{num} is an even number.")
else:
    print(f"{num} is an odd number.")'''

# 12. Print gender (Male/Female) program according to given M/F using switch

gender_input = input("Enter gender (M/F): ")

# Dictionary to map input to output
gender_dict = {
    'M': 'Male',
    'F': 'Female'
}

# Switch case implementation
gender = gender_dict.get(gender_input, 'Invalid input')

# Printing the corresponding gender
print("Gender is:", gender)







