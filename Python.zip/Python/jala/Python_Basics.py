#ques 1- Write a program to print your name.
print('Shrasti Sharma')


# 2. Write a program for a Single line comment and multi-line comments

# Single Line comment (we use ctrl+/)


#         We can comment using two method one is single quote ''      
# another is selecting whole text then press ctrl+/

'''multiline 
comment'''

# second way for
# multiline 
# comment   



#    *********** 3. Define variables for different Data Types int, Boolean, char, 
# float, double and print on the Console
          

# my_int = 10
# my_boolean = True
# my_char = 'A'
# my_float = 3.14
# my_double = 2.71828

# print("Integer value:", my_int)
# print("Boolean value:", my_boolean)
# print("Character value:", my_char)
# print("Float value:", my_float)
# print("Double value:", my_double)



# 4. Define the local and Global variables with the same name and print both variables and 
# understand the scope of the variable
''''my_variable = 20  # Global variable

def my_function():
    my_variable = 10  # Local variable with the same name
    print("Local variable:", my_variable)

my_function()
print("Global variable:", my_variable)'''

'''When you run this Python code, it will output the value of the local variable within the
function(which will be 10) and the value of the global variable after the function call(which will be 20).'''




