# 1. Write a program to generate Arithmetic Exception without exception handling 

result = 10 / 0

# This line will not be executed because the exception will terminate the program
print("This will not be printed")


# 2. Handle the Arithmetic exception using try-catch block


try:
    result = 10 / 0
except ZeroDivisionError as e:
    print(f"An error occurred: {e}")

print("This will be printed because the exception was handled.")


# 3. Write a method which throws exception, Call that method in main class without try block

class MyClass:
    def method_that_throws(self):
        raise Exception("This is an exception")

# Main execution
obj = MyClass()
obj.method_that_throws()

print("This will not be printed because the exception was not handled")

# 4. Write a program with multiple catch blocks 

def divide_numbers(a, b):
    try:
        result = a / b
        print("Result of division:", result)
    except ZeroDivisionError as e:
        print("Caught ZeroDivisionError:", e)
    except TypeError as e:
        print("Caught TypeError:", e)
    except Exception as e:
        print("Caught Exception:", e)

# Test the divide_numbers function
divide_numbers(10, 2)  # No exception
divide_numbers(10, 0)  # ZeroDivisionError
divide_numbers("10", 2)  # TypeError