from packages.car import Car
from packages.computer import Computer

# Create instances of Car and Computer
car_instance = Car("Toyota", "Camry")
computer_instance = Computer("Apple", "Intel Core i7")

# Call methods of each instance
car_instance.display_info()
computer_instance.display_info()
