# 1. Write a function to add integer values of an array
'''
def sum_of_array(arr):
    total = 0
    for num in arr:
        total += num
    return total

array = [1, 2, 3, 4, 5]
print("The sum of the array is:", sum_of_array(array))'''

# 2. Write a function to calculate the average value of an array of integers

def average_of_array(arr):
    if not arr:
        return 0  # Return 0 if the array is empty to avoid division by zero
    total = sum(arr)
    count = len(arr)
    average = total / count
    return average

array = [1, 2, 3, 4, 5]
print("The average of the array is:", average_of_array(array))

# 3. Write a program to find the index of an array element
'''
def cal_average(num):
    sum_num = 0
    #Loop through the array to average value of elements 
    for i in num:
        sum_num = sum_num + i          

    avg = sum_num / len(num)
    return avg

print("The average is", cal_average([10,21,32,43,54]))'''

# 4. Write a function to test if array contains a specific value

def contains_value(arr, value):
    return value in arr

arr = [1, 2, 3, 4, 5]
value = 3
if contains_value(arr, value):
    print(f"The array contains the value {value}.")
else:
    print(f"The array does not contain the value {value}.")
# 5. Write a function to remove a specific element from an array
'''
def remove_element(arr, element):
    if element in arr:
        arr.remove(element)
        return arr
    else:
        return "Element not found in the array"

arr = [1, 2, 3, 4, 5]
element = 3

result = remove_element(arr, element)
print(result)
'''
# 6. Write a function to copy an array to another array
'''def copy_array(arr):
    return arr.copy()

arr1 = [1, 2, 3, 4, 5]
arr2 = copy_array(arr1)

print(f"Original array: {arr1}")
print(f"Copied array: {arr2}")'''


# 7. Write a function to insert an element at a specific position in the array
'''def insert_element(arr, element, position):
    arr.insert(position, element)
    return arr

arr = [1, 2, 3, 4, 5]
element = 100
position = 2

result = insert_element(arr, element, position)
print(result)'''

# 8. Write a function to find the minimum and maximum value of an array
'''
def find_min_max(arr):
    if not arr:
        return None, None
    
    min_value = min(arr)
    max_value = max(arr)
    
    return min_value, max_value

arr = [5, 2, 9, 1, 7, 3]
min_val, max_val = find_min_max(arr)

print(f"Minimum value: {min_val}")
print(f"Maximum value: {max_val}")'''

# 9. Write a function to reverse an array of integer values
'''
arr = [1, 2, 3, 4, 5]
left = 0
right = len(arr) - 1

while left < right:
    arr[left], arr[right] = arr[right], arr[left]
    left += 1
    right -= 1

print("Reversed array:", arr)
'''

# 10. Write a function to find the duplicate values of an array
'''
arr = [1, 2, 3, 4, 3, 2, 5]
duplicates = []

for i in range(len(arr)):
    for j in range(i+1, len(arr)):
        if arr[i] == arr[j] and arr[i] not in duplicates:
            duplicates.append(arr[i])

print("Duplicate values:", duplicates)'''


# 11. Write a program to find the common values between two arrays
'''arr1 = [1, 2, 3, 4, 5]
arr2 = [3, 4, 5, 6, 7]

common_values = []

for num1 in arr1:
    for num2 in arr2:
        if num1 == num2 and num1 not in common_values:
            common_values.append(num1)

print("Common values:", common_values)
'''

# 12. Write a method to remove duplicate elements from an array
'''
def remove_duplicates(arr):
    unique_vals = []
    
    for num in arr:
        if num not in unique_vals:
            unique_vals.append(num)
    
    return unique_vals
arr = [1, 2, 3, 4, 3, 2, 5]
arr = remove_duplicates(arr)

print("Array after removing duplicates:", arr)
'''

# 13. Write a method to find the second largest number in an array
'''
def find_second_largest(arr):
    first_largest = float('-inf')
    second_largest = float('-inf')
    
    for num in arr:
        if num > first_largest:
            second_largest = first_largest
            first_largest = num
        elif num > second_largest and num != first_largest:
            second_largest = num
    
    return second_largest

arr = [10, 5, 7, 15, 3]
second_largest = find_second_largest(arr)

print("Second largest number:", second_largest)'''

# 14. Write a method to find the second largest number in an array

'''def find_second_largest(arr):
    first_largest = float('-inf')
    second_largest = float('-inf')
    
    for num in arr:
        if num > first_largest:
            second_largest = first_largest
            first_largest = num
        elif num > second_largest and num != first_largest:
            second_largest = num
    
    return second_largest

arr = [10, 5, 7, 15, 3]
second_largest = find_second_largest(arr)

print("Second largest number:", second_largest)'''

# 15. Write a method to find number of even number and odd numbers in an array
'''def count_even_odd(arr):
    even_count = 0
    odd_count = 0
    
    for num in arr:
        if num % 2 == 0:
            even_count += 1
        else:
            odd_count += 1
    
    return even_count, odd_count

arr = [1, 2, 3, 4, 5, 6, 7, 8, 9]
even_count, odd_count = count_even_odd(arr)

print("Number of even numbers:", even_count)
print("Number of odd numbers:", odd_count)'''

# 16. Write a function to get the difference of largest and smallest value
'''
def get_difference(arr):
    if not arr:
        return None
    
    min_val = float('inf')
    max_val = float('-inf')
    
    for num in arr:
        if num < min_val:
            min_val = num
        if num > max_val:
            max_val = num
    
    return max_val - min_val

# Example usage
arr = [10, 5, 7, 15, 3]
difference = get_difference(arr)

print("Difference between largest and smallest value:", difference)'''
# 17. Write a method to verify if the array contains two specified elements(12,23)
'''arr = [10, 5, 12, 15, 23]
element1 = 12
element2 = 23

contains_element1 = False
contains_element2 = False

for num in arr:
    if num == element1:
        contains_element1 = True
    if num == element2:
        contains_element2 = True

if contains_element1 and contains_element2:
    print("The array contains both 12 and 23.")
else:
    print("The array does not contain both 12 and 23.")'''

# 18. Write a program to remove the duplicate elements and return the new array
'''
def remove_duplicates(arr):
    return list(set(arr))

arr = [1, 2, 3, 2, 4, 5, 3]
new_arr = remove_duplicates(arr)

print("Original array:", arr)
print("Array after removing duplicates:", new_arr)'''