class Computer:
    def __init__(self, brand, cpu):
        self.brand = brand
        self.cpu = cpu

    def display_info(self):
        print(f"This computer is a {self.brand} with {self.cpu} CPU")
