# 1. Create a Dictionary with at least 5 key value pairs of the Student ID and Name 
# 1.1. Adding the values in dictionary 
# 1.2. Updating the values in dictionary 
# 1.3. Accessing the value in dictionary 
# 1.4. Create a nested loop dictionary 
# 1.5. Access the values of nested loop dictionary 
# 1.6. Print the keys present in a particular dictionary 
# 1.7. Delete a value from a dictionary 

# 1. Create a Dictionary with at least 5 key value pairs of the Student ID and Name
student_dict = {"101": "Alice", "102": "Bob", "103": "Charlie", "104": "David", "105": "Eve"}

# 1.1. Adding values to the dictionary
student_dict["106"] = "Frank"

# 1.2. Updating the values in the dictionary
student_dict["101"] = "Alex"

# 1.3. Accessing the value in the dictionary
print("Value for key '103':", student_dict["103"])

# 1.4. Create a nested loop dictionary
nested_dict = {
    "A": {"1": "Apple", "2": "Ant"},
    "B": {"1": "Ball", "2": "Banana"}
}

# 1.5. Access the values of nested loop dictionary
for key, nested in nested_dict.items():
    print("Key:", key)
    for nested_key, value in nested.items():
        print("\tNested Key:", nested_key, "Value:", value)

# 1.6. Print the keys present in a particular dictionary
print("Keys present in student_dict:", student_dict.keys())

# 1.7. Delete a value from a dictionary
del student_dict["104"]
print("After deleting key '104':", student_dict)