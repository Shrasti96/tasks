# 1. Create a class with PRIVATE fields, private method and a main method. Print the fields 
# in main method. Call the private method in main method. 
# Create a sub class and try to access the private fields and methods from sub class. 
# 2. Create a class with PROTECTED fields and methods. Access these fields and methods 
# from any other class in the same package.  
# Also, Access the PROTECTED fields and methods from child class located in a different 
# package 
# Access the PROTECTED fields and methods from any class in different package 
# 3. Create a class with PUBLIC fields and methods.  
# Access the public methods and fields from any class in the same package or different 
# package.



# Super class
class Parent:
     
     # public data member
     public_field = None
 
     # protected data member
     _protected_field = None
      
     # private data member
     __private_field = None
     
     # constructor
     def __init__(self, public_field, protected_field, private_field): 
          self.public_field = public_field
          self._protected_field = protected_field
          self.__private_field = private_field
     
     # public member function  
     def displayPublicMembers(self):
          # accessing public data members
          print("Public Data Member: ", self.public_field)
        
     # protected member function  
     def _displayProtectedMembers(self):
          # accessing protected data members
          print("Protected Data Member: ", self._protected_field)
      
     # private member function  
     def __displayPrivateMembers(self):
          # accessing private data members
          print("Private Data Member: ", self.__private_field)
 
     # public member function
     def accessPrivateMembers(self):    
          # accessing private member function
          self.__displayPrivateMembers()
  
# Derived class
class Child(Parent):
  
     # constructor
     def __init__(self, public_field, protected_field, private_field):
          Parent.__init__(self, public_field, protected_field, private_field)
           
     # public member function
     def accessProtectedMembers(self):
          # accessing protected member functions of super class
          self._displayProtectedMembers()
  
# Creating objects of the derived class    
obj = Child("Public Value", 10 , "Private Value")
 
# Calling public member functions of the class
obj.displayPublicMembers()
obj.accessProtectedMembers()
obj.accessPrivateMembers()
 
# Object can access protected member
print("Object is accessing protected member:", obj._protected_field)
