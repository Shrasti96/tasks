# 1. Write a function for arithmetic operators(+,-,*,/)
'''
def arithmetic_operation(num1, num2, operator):
    if operator == '+':
        return num1 + num2
    elif operator == '-':
        return num1 - num2
    elif operator == '*':
        return num1 * num2
    elif operator == '/':
        if num2 != 0:
            return num1 / num2
        else:
            return "Division by zero is not allowed"
    else:
        return "Invalid operator"

        
# Input numbers and operator from the user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
operator = input("Enter the operator (+, -, *, /): ") 

# Perform the arithmetic operation
result = arithmetic_operation(num1, num2, operator)


print(f"{num1} {operator} {num2} = {result}")'''


# 2. Write a method for increment and decrement operators(++, --)

'''def increment(num):
    num += 1
    return num

def decrement(num):
    num -= 1
    return num

number = 5
print("Initial value:", number)
number = increment(number)
print("After increment:", number)
number = decrement(number)
print("After decrement:", number)'''


# 3. Write a program to find the two numbers equal or not

'''
n1 = int(input("Enter the number_1:"))
n2 = int(input("Enter the number_2:"))

# Check if the numbers are equal
if n1 == n2:
    print("The two numbers are equal.")
else:
    print("The two numbers are not equal.")'''


# 4. Program for relational operators (<,<==, >, >==)

'''
a = 10
b = 20

# Using the less than operator
if a < b:
    print(f"{a} is less than {b}")

# Using the less than or equal to operator
if a <= b:
    print(f"{a} is less than or equal to {b}")

# Using the greater than operator
if b > a:
    print(f"{b} is greater than {a}")

# Using the greater than or equal to operator
if b >= a:
    print(f"{b} is greater than or equal to {a}")

# Using the equal to operator
if a == b:
    print(f"{a} is equal to {b}")


# Using the not equal to operator
if a != b:
    print(f"{a} is not equal to {b}")

else:
    print("No operation have to perform")
'''



# 5. Print the smaller and larger number

'''a = int(input("Enter the number:"))
b = int(input("Enter the number:"))

# Determine the smaller and larger number
if a < b:
    smaller = a
    larger = b
elif a > b:
    smaller = b
    larger = a
else:
    smaller = larger = a

# Print the results
print(f"The smaller number is {smaller}")
print(f"The larger number is {larger}")
'''