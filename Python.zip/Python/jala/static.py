# 1. Define a static variable and access that through a class 
# 2. Define a static variable and access that through a instance
# 3. Define a static variable and change within the instance
# 4. Define a static variable and change within the class


class MyClass:
# Access through class    
 staticVariable = 9 
print("Access through class ",MyClass.staticVariable)

#Change within an class
MyClass.staticVariable = 12
print('Change within an class',MyClass.staticVariable) # Gives 12

#Access through an instance
instance = MyClass()
print("Access through an instance",instance.staticVariable) # Gives 12

#Change within an instance
instance.staticVariable = 15
print("Change within an instance",instance.staticVariable) # Gives 15
print("Change within an instance",MyClass.staticVariable) #Gives 12