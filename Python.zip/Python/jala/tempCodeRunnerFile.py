
    print(number, "is not a prime number")