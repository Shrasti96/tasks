# 1. Write two methods with the same name but different number of parameters of same type 
# and call the methods  

class MyClass:
    def method(self, a, b=None):
        if b is not None:
            print(f"Method called with two parameters: {a}, {b}")
        else:
            print(f"Method called with one parameter: {a}")

obj = MyClass()
obj.method(10)
obj.method(10, 20)



# 2. Write two methods with the same name but different number of parameters of different 
# data type and call the methods  

class MyClass:
    def method(self, a, b=None):
        if isinstance(a, int) and isinstance(b, int):
            print(f"Method called with two integers: {a}, {b}")
        elif isinstance(a, str) and isinstance(b, str):
            print(f"Method called with two strings: '{a}', '{b}'")
        else:
            print(f"Method called with one parameter: {a}")

obj = MyClass()
obj.method(10)
obj.method("hello")
obj.method(10, 20)
obj.method("hello", "world")

# 3. Write two methods with the same name and same number of parameters of same type 
class MyClass:
    def method(self, a, b):
        if isinstance(a, int) and isinstance(b, int):
            print(f"Method called with two integers: {a}, {b}")
        elif isinstance(a, str) and isinstance(b, str):
            print(f"Method called with two strings: '{a}', '{b}'")
        else:
            print(f"Method called with two parameters of same type: {a}, {b}")

obj = MyClass()
obj.method(10, 20)
obj.method("hello", "world")
