class X():  
    def display(self):
        print("Display Inside class X")
        
    def show(self):
        print("Show Inside class X")
    
class Y(X): 
    def print_msg(self):
        print("Print Inside class Y")
    
    def show(self):
        print("Show Inside class Y")
    
class Z(Y):          
    def show(self):
        print("Show Inside class Z")
    
# Driver code 
obj_X = X()
obj_X.display()
obj_Y = Y()
obj_Y.print_msg()
obj_Z = Z()   
obj_Z.show()                 
